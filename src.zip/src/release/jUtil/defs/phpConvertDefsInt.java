package release.jUtil.defs;

/**
  Copyright (C) 2015, 2018 Ettore Merlo - All rights reserved
*/

public interface phpConvertDefsInt {
    static final int FILE_EXT_LIMIT = 10;
    static final int FILE_NAME_LIMIT = 30;
    static final int FILE_PATH_LIMIT = 120;
}
