package release.jUtil.defs;

public interface ptfaHashConstantsInt {

    final int FRONTIER_PTFA_PRIV = -1111;

    final int HASH_PRIME_PROPERTY = 1531;
    // roughly the max number of distinct properties


    final int HASH_PRIME_CFG_NODES = 6143;
    //final int HASH_PRIME_CFG_NODES = 24571;
    // roughly the span of node ids in a chunk

    final int HASH_PRIME_CONTRIB = 12289;
    // hagher than abs(UNDEF_VAL)
}
