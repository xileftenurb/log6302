package release.jUtil.defs;

/**
  Copyright (C) 2015, 2018 Ettore Merlo - All rights reserved
*/

public interface defsInt {
    static final int UNDEF_VAL = -9999;
    static final int BOTTOM_UNDEF_VAL = -9999;
    static final int TOP_UNDEF_VAL = +9999;
}
