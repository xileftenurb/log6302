#!/usr/bin/python
#
#  Copyright (C) 2014 Ettore Merlo - All rights reserved
#


import sys
import string
import re

fo = sys.stdout

#
# ASCII:
#
#       Oct   Dec   Hex   Char
#
#       034   28    1C    FS  (file separator)
#       035   29    1D    GS  (group separator)
#       036   30    1E    RS  (record separator)
#       037   31    1F    US  (unit separator)
#

fo.write('TAG:\037<ParmVarDecl>\037\n\037\036');
fo.write('ATTR:\037varName\037reader\037\n\037\036');
fo.write('ATTR:\037varTypeClass\037Pointer\037\n\037\036');
fo.write('ATTR:\037colBegin\03734\037\n\037\036');
fo.write('ATTR:\037varType\037class dwarf2reader::ByteReader *\037\n\037\036');
fo.write('ATTR:\037lineEnd\03755\037\n\037\036');
fo.write('ATTR:\037colEnd\03746\037\n\037\036');
fo.write('ATTR:\037lineBegin\03755\037\n\037\036');
fo.write('ATTR:\037id\0376\037\n\037\036');
fo.write('ATTR:\037\* this is a \012multiline comment*/\037\n\037\036');
fo.write('ATTR:\037\* this is another \nmultiline comment*/\037\n\037\036');

sys.exit(0)
