#!/usr/bin/python

##########################################################################
#                                                                        #
#                                                                        #
#   PROCEDURE NAME: pEncode.py
#
#   AUTHOR: Ettore Merlo                           DATE: Sept 20, 2014
#
#   DESCRIPTION: 
# 
# Usage: ./number.py [-h] [-i/--input input] [-o/--output file]
# 
# Options:
#   -h --help : this help
#   -i --input : input file (stdin by default)
#   -o --output : output file (stdout by default)
#   -w --warnings < on / off > : warnings enable (warnings are in effect by default)
# 
#   -s --sum : prints the sum of values (inactive by default)
# 
# Computes average and variance of an input numerical column
#
#   PARAMETERS:
#
#   RETURN VALUE: 0 - normal termination
#                 1 - errors
#
#   FILES ACCESSED:
#
#   COMPILER: Python                               VERSION: 1.5.2
#
#   OPERATING SYSTEM: Linux RedHat 6.2
#
#   HARDWARE: Pentium II
#
#   COPYRIGHT: Ettore Merlo, 2014 - All rights reserved
#                                                                        #
#                                                                        #
##########################################################################

import sys
import string
import re
import getopt
#import math
#import statsFunc

fi = sys.stdin
fo = sys.stdout
fe = sys.stderr

seed = 1

def usage():
	sys.stdout.write('\n')
	sys.stdout.write('Usage: ' + sys.argv[0] + ' [-h] [-i/--input input] [-o/--output file]\n\n')
	sys.stdout.write('Options:\n')
	sys.stdout.write('  -h --help : this help\n')
	sys.stdout.write('  -i --input : input file (stdin by default)\n')
	sys.stdout.write('  -o --output : output file (stdout by default)\n')
	sys.stdout.write('\n')

try:
	opts, args = getopt.getopt(sys.argv[1:],
		"hi:o:s:", ["help", "input=", "output=", "seed="])

except getopt.error:
	usage()
	sys.exit(1)

for o, v in opts:
	if o in ("-h", "--help"):
		usage()
		sys.exit(1)
	elif o in ("-i", "--input"):
		fi = open(v, 'r')
	elif o in ("-o", "--output"):
		fo = open(v, 'w')
	elif o in ("-s", "--seed"):
                try:
                        seed = int(v)
                except ValueError:
			fe.write('ERROR: invalid seed \'' +
                                       v + '\'\n')
			sys.exit(1)
	else:
		sys.stderr.write('ERROR: cannot process option ' + o + '\n')
		sys.exit(1)

#print 'ARGS: ', args

if len(args) > 0:
	sys.stderr.write('ERROR: no arguments allowed\n')
	usage()
	sys.exit(1)

line = fi.readline()
while line != "":

	line = re.sub('\n$', '', line)
        words = string.split(line)

	for w in words:
		fo.write(w + '\037')
	fo.write('\n\037\036')

        line = fi.readline()

sys.exit(0)
