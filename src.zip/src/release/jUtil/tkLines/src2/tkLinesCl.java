package release.jUtil.tkLines.src2;

import java.io.*;
import java.util.*;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

/**
  Copyright (C) 2014 Ettore Merlo - All rights reserved
 */

class tkLinesCl implements defsInt {

    Scanner s = null;

    boolean open(String linesFileName) 
    //throws IOException,FileNotFoundException
    {

	try {
	    s = new Scanner(new BufferedReader(new FileReader(linesFileName)));
	}
	catch (IOException e) {
	    System.err.println("ERROR: cannot open: " +
			       linesFileName);
	    System.err.println("ERROR: " +
			       e.getMessage());
	    return(true);
	}

	return(false);
    };

    boolean close()
    //throws IOException
    {

	s.close();

	return(false);
    };

    Integer getIntWord() {

	String str = "";
	//int iVal = UNDEF_VAL;
	Integer iRetVal = null;

	if (s.hasNext()) {

	    str = s.next();
	    //System.out.println("TYPE: " + str);

	    try {
		iRetVal = Integer.valueOf(str);
	    }
	    catch (NumberFormatException e) {
		System.err.println("ERROR: invalid integer value: \"" +
				   str +
				   "\"");
		System.err.println("ERROR: " +
				   e.getMessage());
		return(null);
	    }

	    return(iRetVal);
	} else {
	    return(null);
	}
    }

    String getWord() {

	String str = "";

	if (s.hasNext()) {

	    str = s.next();
	    //System.out.println("TYPE: " + str);

	    return(str);
	} else {
	    return(null);
	}
    }

    String getLine() {

	String str = "";

	if (s.hasNext()) {

	    str = s.nextLine();
	    //System.out.println("TYPE: " + str);

	    return(str);
	} else {
	    return(null);
	}
    }

    String getStrippedLine() {

	String str = "";
	int i = UNDEF_VAL;
	char c = '\0';
	boolean proceed = false;

	if (s.hasNext()) {

	    str = s.nextLine();
	    //System.out.println("TYPE: " + str);

	    i = 0;
	    proceed = true;
	    while ((i < str.length()) && (proceed)){

		c = str.charAt(i);
		if ((c != ' ') && (c != '\t')) {
		    proceed = false;
		} else {
		    i++;
		}
	    }

	    return(str.substring(i));
	} else {
	    return(null);
	}
    }

    boolean nextIsValid() {

	if (s.hasNext())
	    return(true);
	else
	    return(false);
    }


    /*


    bool firstLine(String linesFileName) 
	throws IOException {


	return(false);
    };

    bool currentLineIsValid() {

	return(false);
    };

    bool getCurrentLine(string& str) {

	return(false);
    };

    bool nextLine() 
	throws IOException {

	return(false);
    };
  
    bool firstWord() {

	return(false);
    };

    bool currentWordIsValid() {

	return(false);
    };

    bool getCurrentWord(string& str) {

	return(false);
    };

    bool intGetCurrentWord(int& iVal) {

 	return(false);
   };

    bool doubleGetCurrentWord(double& dVal) {

 	return(false);
   };

    bool boolGetCurrentWord(bool& bVal) {

	return(false);
    };

    bool nextWord() {

 	return(false);
   };

    bool wordAt(int pos, string& str) {

 	return(false);
   };

    bool intWordAt(int pos, int& iVal) {

	return(false);
    };

    bool doubleWordAt(int pos, double& dVal) {

	return(false);
    };

    bool boolWordAt(int pos, bool& bVal) {

	return(false);
    };

    bool restLineAt(int pos, string& str) {

	return(false);
    };

    bool nWords(int& nw) {

 	return(false);
   };

    */



}
