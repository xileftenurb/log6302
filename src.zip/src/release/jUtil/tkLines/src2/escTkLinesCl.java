package release.jUtil.tkLines.src2;

import java.io.*;
import java.util.*;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

/**
  Copyright (C) 2014 Ettore Merlo - All rights reserved
 */

public class escTkLinesCl implements defsInt, escTkLinesInt {

    //Scanner s2 = null;
    BufferedReader s = null;

    boolean currentIsValid = false;

    ArrayList<String> localLineStr = null;
    boolean localEofFlag = true;

    private final int TXT_EOLN = 10; // LF  '\n' (new line)
    private final int TXT_EOT = 32; // SPACE
    private final int TXT_ESCAPE = 92; // BACK_SLASH

    private final int EOF = -1;

    private final int ERROR_STATE = 0;

    private final int START_LINE_STATE = 1;
    private final int IN_WORD_STATE = 2;
    private final int END_OF_WORD_STATE = 3;
    private final int END_OF_LINE_STATE = 4;
    private final int END_OF_FILE_STATE = 5;
    private final int WORD_ESCAPE_STATE = 6;


    public boolean open(String linesFileName) 
    //throws IOException,FileNotFoundException
    {

	//System.out.println("OPEN: " + linesFileName);

	try {
	    //s = new Scanner(new BufferedReader(new FileReader(linesFileName)));
	    s = new BufferedReader(new FileReader(linesFileName));
	}
	catch (IOException e) {
	    System.err.println("ERROR: cannot open: " +
			       linesFileName);
	    System.err.println("ERROR: " +
			       e.getMessage());
	    return(true);
	}

	return(false);
    };


    public boolean close()
    //throws IOException
    {
	try {

	s.close();

     } catch ( IOException e ) {
         System.err.print( e );
	    return(true);
	    //} /* endcatch */
       }

	return(false);
    };


    public String getLine() {

	String str = "";
	int c;

	/*
	if (s.hasNext()) {

	    str = s.next();
	    //System.out.println("TYPE: " + str);

	    return(str);
	} else {
	    return(null);
	}
	*/

       try {
 
	   while ((c = s.read()) != -1) {
	       if ((char) c != '\n') {
		   //str.append((char) c);

		   str.concat(String.valueOf(c));

		   //outputStream.write(c);
	       }
	   }


       } catch ( IOException e ) {
	   System.err.print( e );
	   return(null);
	    //} /* endcatch */
       }

       return(str);
    }


    public boolean readNext() {

	//
	// read escaped text lines
	//

	int curSymb = UNDEF_VAL;
	boolean proceed = false;

	char[] cBuf = new char[1];
	cBuf[0] = '\0';

	String str = null;

	int cur_state = UNDEF_VAL;

	//
	// should the initialization really be here and be eof == false ?
	//

	currentIsValid = false;
	localLineStr = null;

	try {
 
	    cur_state = START_LINE_STATE;

	    while ((cur_state != END_OF_LINE_STATE) &&
		   (cur_state != END_OF_FILE_STATE) &&
		   (cur_state != ERROR_STATE)) {

		//
		// all states read one symbol
		// (otherwise put read into state actions)
		//

		curSymb = s.read();
		//System.out.println("INT_CH: " + curSymb);
		//System.out.println("CH: " + (char) curSymb);

		/*
		System.out.println("STATE: " + cur_state);
		if (curSymb > 0) {
		    System.out.println("CH: " + (char) curSymb);
		} else {
		    System.out.println("CH: EOF");
		}
		System.out.println();
		*/

		switch (cur_state) {

		case START_LINE_STATE:

		    //
		    // START_LINE_STATE actions
		    //

		    // no actions

		    //
		    // START_LINE_STATE transitions
		    //

		    switch (curSymb) {

		    case TXT_EOT:

			//
			// START_LINE_STATE, TXT_EOT transition
			//

			localLineStr = new ArrayList<String>();
			localLineStr.add(new String(""));

			//
			// next state: END_WORD_STATE
			//

			cur_state = END_OF_WORD_STATE;

			break;

		    case TXT_EOLN:

			//
			// START_LINE_STATE, TXT_EOLN transition
			//

			localLineStr = new ArrayList<String>();
			currentIsValid = true;

			//
			// next state: END_LINE_STATE
			//

			cur_state = END_OF_LINE_STATE;

			break;

		    case EOF:

			//
			// START_LINE_STATE, EOF transtition
			//

			localLineStr = null;
			currentIsValid = false;

			//
			// next state: END_OF_FILE_STATE
			//

			cur_state = END_OF_FILE_STATE;

			break;

		    case TXT_ESCAPE:

			//
			// START_LINE_STATE, TXT_ESCAPE transition
			//

			localLineStr = new ArrayList<String>();
			str = new String("");

			//
			// next state: WORD_ESCAPE_STATE
			//

			cur_state = WORD_ESCAPE_STATE;

			break;

		    default:

			//
			// START_LINE_STATE, CH transition
			//

			localLineStr = new ArrayList<String>();

			cBuf[0] = (char) curSymb;
			str = new String(cBuf);

			//
			// next state: IN_WORD_STATE
			//

			cur_state = IN_WORD_STATE;

		    } //end transitions START_LINE_STATE

		    break;


		case IN_WORD_STATE:
 
		    //
		    // IN_WORD_STATE actions
		    //

		    // no actions

		    //
		    // IN_WORD_STATE transitions
		    //

		    /*
		    System.out.println("DEBUG IN_WORD_STATE 1 CUR_SYMB: " +
				       curSymb);
		    */

		    switch (curSymb) {

		    case TXT_EOT:

			/*
			System.out.println("DEBUG IN_WORD_STATE 2: " +
					   localLineStr);
			System.out.println("DEBUG IN_WORD_STATE 3 CUR_SYMB: " +
					   curSymb);
			*/

			//
			// IN_WORD_STATE, TXT_EOT transition
			//

			//System.out.println("STR: " + str);

			localLineStr.add(str);

			//
			// next state: END_OF_WORD_STATE
			//

			cur_state = END_OF_WORD_STATE;

			/*
			System.out.println("DEBUG IN_WORD_STATE 4: " +
					   localLineStr);
			System.out.println("DEBUG IN_WORD_STATE 5 CUR_SYMB: " +
					   curSymb);
			*/

			break;

		    case TXT_EOLN:

			//
			// IN_WORD_STATE, TXT_EOLN transition
			//

			//System.out.println("STR: " + str);

			currentIsValid = true;
			localLineStr.add(str);


			//
			// next state: END_OF_LINE_STATE
			//

			cur_state = END_OF_LINE_STATE;

			break;

		    case EOF:

			//
			// IN_WORD_STATE, EOF transition
			//

			System.out.println("ERROR: EOF encountered in field " + str);
			currentIsValid = false;
			localLineStr = null;

			//
			// next state: ERROR_STATE
			//

			cur_state = ERROR_STATE;

			break;

		    case TXT_ESCAPE:

			//
			// IN_WORD_STATE, TXT_ESCAPE transition
			//

			// no action

			//
			// next state: WORD_ESCAPE_STATE
			//

			cur_state = WORD_ESCAPE_STATE;

			break;

		    default:

			//
			// IN_WORD_STATE, CH transition
			//

			cBuf[0] = (char) curSymb;
			str = str.concat(new String(cBuf));

			//
			// next state: IN_WORD_STATE
			//

			cur_state = IN_WORD_STATE;

		    } // end IN_WORD_STATE transitions

		    break;


		case END_OF_WORD_STATE:

		    /*
		    System.out.println("DEBUG END_OF_WORD_STATE 4 CUR_SYMB: " +
				       curSymb);

		    System.out.println("DEBUG END_OF_WORD_STATE 3 TXT_EOT: " +
				       localLineStr);
		    */

		    //
		    //  END_OF_WORD_STATE actions
		    //

		    // no actions

		    //
		    //  END_OF_WORD_STATE transitions
		    //

		    switch (curSymb) {

		    case TXT_EOT:

			//
			// this seems dead code in practice
			// for escaped tk lines
			// (never traversed in tests)
			// addition of a new empty string is
			// done in case TXT_EOLN rather
			//

			/*
			System.out.println("DEBUG END_OF_WORD_STATE 1 TXT_EOT: " +
					   localLineStr);
			*/

			//
			// END_OF_WORD_STATE, TXT_EOT transition
			//

			localLineStr.add(new String(""));

			//
			// next state: END_OF_WORD_STATE
			//

			cur_state = END_OF_WORD_STATE;

			/*
			System.out.println("DEBUG END_OF_WORD_STATE 2 TXT_EOT: " +
					   localLineStr);
			*/

			break;

		    case TXT_EOLN:

			/*
			System.out.println("DEBUG END_OF_WORD_STATE 5 CUR_SYMB: " +
					   curSymb);

			System.out.println("DEBUG END_OF_WORD_STATE 5 TXT_EOLN: " +
					   localLineStr);
			*/

			// new introduction of empty string
			// replacing the dead one from case TXT_EOT
			localLineStr.add(new String(""));

			//
			// END_OF_WORD_STATE, TXT_EOLN transition
			//

			currentIsValid = true;

			//
			// next state: END_OF_LINE_STATE
			//

			cur_state = END_OF_LINE_STATE;

			break;

		    case EOF:

			//
			// END_OF_WORD_STATE, EOF transtition
			//

			System.out.println("ERROR: EOF encountered after field " + str);
			currentIsValid = false;
			localLineStr = null;

			//
			// next state: ERROR_STATE
			//

			cur_state = ERROR_STATE;

			break;

		    case TXT_ESCAPE:

			//
			// END_OF_WORD_STATE, TXT_ESCAPE transition
			//


			//////////////////////////////////////////


			//localLineStr.add(new String(""));

			str = new String("");

			/////////////////////////////////////////

			//
			// next state: WORD_ESCAPE_STATE
			//

			cur_state = WORD_ESCAPE_STATE;

			break;

		    default:

			//
			// END_OF_WORD_STATE, CH transition
			//

			cBuf[0] = (char) curSymb;
			str = new String(cBuf);

			//
			// next state: IN_WORD_STATE
			//

			cur_state = IN_WORD_STATE;

		    } //end transitions END_OF_WORD_STATE

		    break;

		case WORD_ESCAPE_STATE:

		    switch (curSymb) {

		    case TXT_EOT:
		    case TXT_EOLN:
		    case TXT_ESCAPE:

			//
			// WORD_ESCAPE_STATE, TXT_EOT transition
			// WORD_ESCAPE_STATE, TXT_EOLN transition
			// WORD_ESCAPE_STATE, TXT_ESCAPE transition
			//

			cBuf[0] = (char) curSymb;
			str = str.concat(new String(cBuf));

			//
			// next state: IN_WORD_STATE
			//

			cur_state = IN_WORD_STATE;

			break;

		    default:

			//
			// WORD_ESCAPE_STATE, CH transition
			//

			System.out.println("ERROR: invalid escaped character " + (char) curSymb);
			currentIsValid = false;
			localLineStr = null;


			//
			// next state: ERROR_STATE
			//

			cur_state = ERROR_STATE;

		    } //end transitions WORD_ESCAPE_STATE

		    break;

		default:
		    System.err.println("ERROR: invalid state " + cur_state);
		    currentIsValid = false;
		    localLineStr = null;
		}

	    } // end loop

	    	} catch ( IOException e ) {
	    	    System.err.print( e );
	    	    currentIsValid = false;
	    	    localLineStr = null;
	    	    //} /* endcatch */
	    	}

	if ((cur_state == END_OF_LINE_STATE) ||
	    (cur_state == END_OF_FILE_STATE)) {
	    return(false);
	} else if (cur_state == ERROR_STATE) {
	    currentIsValid = false;
	    localLineStr = null;
	    return(true);
	} else {
	    System.err.println("ERROR: invalid exit state " + cur_state);
	    currentIsValid = false;
	    localLineStr = null;
	    return(true);
	}
    }

    public boolean currentIsValid() {
	return(currentIsValid);
    }

    public ArrayList<String> getCurrent() {
	return(localLineStr);
    }

}
