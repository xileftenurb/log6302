package release.jUtil.tkLines.src2;

import java.io.*;
import java.util.*;

/**
  Copyright (C) 2015 Ettore Merlo - All rights reserved
 */

interface escTkLinesInt {

    public boolean open(String linesFileName);
    public boolean close();
    public  boolean readNext();
    public boolean currentIsValid();
    public ArrayList<String> getCurrent();

}
