package release.jUtil.tkLines.src2;

import java.io.*;
import java.util.*;

/**
  Copyright (C) 2014 Ettore Merlo - All rights reserved
 */

public class tkLinesMain {

    //private static optionsCl astOptions = null;

    public static void main(String[] args) throws IOException {

	tkLinesCl tkLines = new tkLinesCl();
	boolean errCode = true;
	boolean res = false;
	Integer iVal = null;
	String strVal = null;

	errCode = tkLines.open("tkLines.dat");
	if (errCode) {
	    System.out.println("ERROR: cannot open tkLines.dat");
	    System.exit(1);
	}

	res = tkLines.nextIsValid();
	if (res)
	    System.out.println("NEXT IS VALID");
	else
	    System.out.println("NEXT IS NOT VALID");

	iVal = tkLines.getIntWord();
	if (iVal != null)
	    System.out.println("I_VAL: <" + iVal.intValue() + '>');
	else
	    System.out.println("INVALID INTEGER");

	res = tkLines.nextIsValid();
	if (res)
	    System.out.println("NEXT IS VALID");
	else
	    System.out.println("NEXT IS NOT VALID");

	strVal = tkLines.getWord();
	if (strVal != null)
	    System.out.println("STR_VAL: <" + strVal + '>');
	else
	    System.out.println("INVALID STRING");

	res = tkLines.nextIsValid();
	if (res)
	    System.out.println("NEXT IS VALID");
	else
	    System.out.println("NEXT IS NOT VALID");

	strVal = tkLines.getLine();
	if (strVal != null)
	    System.out.println("STR_VAL: <" + strVal + '>');
	else
	    System.out.println("INVALID LINE");

	res = tkLines.nextIsValid();
	if (res)
	    System.out.println("NEXT IS VALID");
	else
	    System.out.println("NEXT IS NOT VALID");

	strVal = tkLines.getStrippedLine();
	if (strVal != null)
	    System.out.println("STR_VAL: <" + strVal + '>');
	else
	    System.out.println("INVALID STRIPPED LINE");

	res = tkLines.nextIsValid();
	if (res)
	    System.out.println("NEXT IS VALID");
	else
	    System.out.println("NEXT IS NOT VALID");


	System.out.println("Normal termination");
    }
}
