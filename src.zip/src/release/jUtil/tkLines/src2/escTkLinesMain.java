package release.jUtil.tkLines.src2;

import java.io.*;
import java.util.*;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

/**
  Copyright (C) 2014 Ettore Merlo - All rights reserved
 */

public class escTkLinesMain implements defsInt {

    //private static optionsCl astOptions = null;

    public static void main(String[] args) throws IOException {

	escTkLinesCl tkLines = new escTkLinesCl();
	boolean errCode = true;
	boolean res = false;
	Integer iVal = null;
	String strVal = null;

	int wIndex = UNDEF_VAL;

	//b_list_str_ret_val_cl retVal = new b_list_str_ret_val_cl();

	ArrayList<String> lineStr = null;

	tkLines = new escTkLinesCl();

	//errCode = tkLines.open3("txtTkLines.dat");
	//errCode = tkLines.open4("txtTkLines.dat");
	//errCode = tkLines.open("bTkLines.dat");
	errCode = tkLines.open("txtTkLines.dat");
	if (errCode) {
	    System.out.println("ERROR: cannot open txtTkLines.dat");
	    System.exit(1);
	}

	//errCode = tkLines.readNext2();
	errCode = tkLines.readNext();
	if (errCode) {
	    System.out.println("ERROR: cannot read first line");
	    System.exit(1);
	}

	while (tkLines.currentIsValid()) {
	    lineStr = tkLines.getCurrent();
	    if (lineStr == null) {
		System.err.println("ERROR: invalid current line");
		System.exit(1);
	    }
	    System.out.println("LINE SIZE: " + lineStr.size());

	    for (wIndex = 0; wIndex < lineStr.size(); wIndex++) {
		System.out.println("WORD[" + wIndex + "] SIZE: " +
				   lineStr.get(wIndex).length() +
				   " STR: <" +
				   lineStr.get(wIndex) +
				   ">");
	    }
	    System.out.println("------------------");

	    //errCode = tkLines.readNext2();
	    errCode = tkLines.readNext();
	    if (errCode) {
		System.out.println("ERROR: cannot read next line");
		System.exit(1);
	    }
	}

	tkLines.close();

	
	System.out.println("Normal termination");
    }
}
