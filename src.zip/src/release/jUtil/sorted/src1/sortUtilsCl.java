package release.jUtil.sorted.src1;

import java.util.Iterator;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Collections;
import java.util.Comparator;

import java.io.File;
import java.io.IOException;

public class sortUtilsCl {

    static int callNo = 0;

    /*
    private static class myComparatorCl
	implements defsInt,
		   Comparator<ArrayList<String>> {

	public int compare(ArrayList<String> arr_1,
			   ArrayList<String> arr_2) {

	    int i = UNDEF_VAL;
	    int res = UNDEF_VAL;
	    boolean proceed = false;

	    i = 0;
	    proceed = true;

	    while (proceed) {

		if (i < arr_1.size()) {

		    //
		    // element exists in arr_1
		    //

		    if (i < arr_2.size()) {

			//
			// element exists in arr_1
			// element exists in arr_2
			//

			if (arr_1.get(i).compareTo(arr_2.get(i)) < 0) {

			    //
			    // arr_1 < arr_2
			    //

			    proceed = false;
			    res = -1;

			} else {

			    //
			    // arr_1 >= arr_2
			    //

			    if (arr_1.get(i).compareTo(arr_2.get(i)) > 0) {

				//
				// arr_1 > arr_2
				//

				proceed = false;
				res = 1;

			    } else {

				//
				// (so far ...) arr_1 == arr_2
				//

				//
				// equality: examine next elements
				//

				++i;

				//proceed = true;
			    }

			} // end (else) arr_1 >= arr_2

			//
			// end case
			// element exists in arr_1
			// element exists in arr_2
			//

		    } else {

			//
			// element exists in arr_1
			// element does not exist in arr_2
			//
			// arr_1 > arr2
			//

			proceed = false;
			res = 1;

			//
			// end case
			// element exists in arr_1
			// element does not exist in arr_2
			//

		    } // end (else) element does not exist in arr_2

		} else {

		    //
		    // element does not exist in arr_1
		    //

		    if (i < arr_2.size()) {

			//
			// element does not exist in arr_1
			// element exists in arr_2
			//
			// arr_1 < arr2
			//

			proceed = false;
			res = -1;

			//
			// end case
			// element does not exist in arr_1
			// element exists in arr_2
			//

		    } else {

			//
			// element does not exist in arr_1
			// element does not exist in arr_2
			//
			// arr_1 == arr2
			//

			proceed = false;
			res = 0;

			//
			// end case
			// element does not exist in arr_1
			// element does not exist in arr_2
			//

		    } // end (else) element does not exist in arr_2

		} // end (else) element does not exist in arr_1

	    } // end while

	    return(res);
	}

	//
	// compare2 is BUGGED
	//

	public int compare2(ArrayList<String> arr_1,
			   ArrayList<String> arr_2) {

	    int i = UNDEF_VAL;
	    int res = UNDEF_VAL;
	    boolean proceed = false;

	    callNo++;

	    i = 0;
	    proceed = true;

	    while (proceed) {

		if (i < arr_1.size()) {

		    //
		    // more unvisited elements of arg
		    //

		    if (i < arr_2.size()) {


			//
			// more unvisited elements of otherArg
			//


			if (arr_1.get(i).compareTo(arr_2.get(i)) < 0) {

			    proceed = false;
			    res = -1;

			} else {

			    if (arr_1.get(i).compareTo(arr_2.get(i)) > 0) {

				proceed = false;
				res = 1;

			    } else {

				//
				// equality: examine next elements
				//

				++i;

				//proceed = true;
			    }
			}
		    } else {

			//
			// no more unvisited elements of otherArg
			//

			proceed = false;
			res = 1;

		    }
		} else {

		    //
		    // no more unvisited elements of arg
		    //

		    proceed = false;
		    res = -1;
		}

		//System.out.println("DEBUG END WHILE");

	    } // end while


	    //
	    // consider the case they are all equal (return 0)
	    //

	    System.out.println("DEBUG CALL_NO: " + callNo);
	    System.out.println("DEBUG ARR_1: " + arr_1);
	    System.out.println("DEBUG ARR_2: " + arr_2);
	    System.out.println("DEBUG RES: " + res);
	    System.out.println();



	    return(res);
	}

	public boolean equals(ArrayList<String> arr_1,
			      ArrayList<String> arr_2) {

	    return(arr_1.equals(arr_2));
	}

    }

    private static myComparatorCl myComparator = new myComparatorCl();

    public static Iterator<String> getSortedIterator(ArrayList<String> tmpArr,
					      HashSet<String> hSet) {
	tmpArr.clear();

	Iterator<String> it = hSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<String> getSortedIterator(HashSet<String> hSet) {

	ArrayList<String> tmpArr = new ArrayList<String>();
	Iterator<String> it = hSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<String> getSortedIterator(Set<String> hSet) {

	ArrayList<String> tmpArr = new ArrayList<String>();
	Iterator<String> it = hSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<String> getSortedIterator(setCl hSet) {

	ArrayList<String> tmpArr = new ArrayList<String>();
	Iterator<String> it = hSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<ArrayList<String>>
	getSorted_Iterator_ArrayList_String(Iterator<ArrayList<String>> it) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();
	ArrayList<ArrayList<String>> tmpArr2 = new ArrayList<ArrayList<String>>();

	while (it.hasNext()) {
	    tmpArr.add(new argCl(it.next()));
	}
	Collections.sort(tmpArr);

	Iterator<argCl> argIt = tmpArr.iterator();
	while (argIt.hasNext()) {

	    argCl argItem = argIt.next();

	    ArrayList<String> argArr = new ArrayList<String>();

	    for (int i=0;i<argItem.size();i++) {
		argArr.add(argItem.get(i));
	    }

	    tmpArr2.add(argArr);
	}

	return(tmpArr2.iterator());
    }

    public static Iterator<argCl> getSortedIterator_argCl(Set<argCl> hSet) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();
	Iterator<argCl> it = hSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<argCl> getSorted_Iterator_argCl(Iterator<argCl> it) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();
	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<argCl> getSortedIterator(mySynchronizedHashSetCl<ArrayList<String>> sSet) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();

	Iterator<ArrayList<String>> it = sSet.iterator();
	while (it.hasNext()) {
	    tmpArr.add(new argCl(it.next()));
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<argCl>
	getSortedIterator_ArrayList_String(Iterator<ArrayList<String>> it) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();

	while (it.hasNext()) {
	    tmpArr.add(new argCl(it.next()));
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<String>
	
	getSortedIterator_String(Iterator<String> it) {

	ArrayList<String> tmpArr = new ArrayList<String>();

	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}
	Collections.sort(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterator<String>
	getSortedReverseIterator_String(Iterator<String> it) {

	ArrayList<String> tmpArr = new ArrayList<String>();

	while (it.hasNext()) {
	    tmpArr.add(it.next());
	}

	Collections.sort(tmpArr);
	Collections.reverse(tmpArr);

	return(tmpArr.iterator());
    }

    public static Iterable<ArrayList<String>> getSortedIterable_ArrayList_String(Iterable<ArrayList<String>> v) {

	ArrayList<ArrayList<String>> tmpArr = new ArrayList<ArrayList<String>>();

	for (ArrayList<String> arr: v) {
	    tmpArr.add(arr);
	}

	Collections.sort(tmpArr, myComparator);

	return(tmpArr);
    }
    */

    public static Iterator<Integer>
	getSortedIterator_Integer(Iterable<Integer> v) {

	ArrayList<Integer> tmpArr = new ArrayList<Integer>();

	for (Integer arr: v) {
	    tmpArr.add(arr);
	}

	Collections.sort(tmpArr);
	return(tmpArr.iterator());
    }

    public static Iterable<String>
	getSortedIterable_String(Iterable<String> v) {

	ArrayList<String> tmpArr = new ArrayList<String>();

	for (String arr: v) {
	    tmpArr.add(arr);
	}

	Collections.sort(tmpArr);

	return(tmpArr);
    }

    public static Iterable<String>
	getIntSortedIterable_String(Iterable<String> v) {

	ArrayList<Integer> iTmpArr = new ArrayList<Integer>();
	ArrayList<String> sTmpArr = new ArrayList<String>();

	for (String strVal: v) {
	    iTmpArr.add(Integer.valueOf(strVal));
	}

	Collections.sort(iTmpArr);

	for (Integer iVal: iTmpArr) {
	    sTmpArr.add(String.valueOf(iVal));
	}

	return(sTmpArr);
    }

    public static Iterable<Integer>
	getSortedIterable_Integer(Iterable<Integer> v) {

	ArrayList<Integer> iTmpArr = new ArrayList<Integer>();

	for (Integer strVal: v) {
	    iTmpArr.add(strVal);
	}

	Collections.sort(iTmpArr);

	return(iTmpArr);
    }

    public static Iterable<Integer>
	getSortedReverseIterable_Integer(Iterable<Integer> v) {

	ArrayList<Integer> iTmpArr = new ArrayList<Integer>();

	for (Integer strVal: v) {
	    iTmpArr.add(strVal);
	}

	Collections.sort(iTmpArr);
	Collections.reverse(iTmpArr);

	return(iTmpArr);
    }

    /*
    public static Iterable<argCl>
	getSortedIterable_argCl(Iterable<argCl> v) {

	ArrayList<argCl> tmpArr = new ArrayList<argCl>();

	for (argCl arr: v) {
	    tmpArr.add(arr);
	}

	Collections.sort(tmpArr);

	return(tmpArr);
    }
    */





}
