package release.jUtil.globalOptions;

import java.io.*;
import java.util.*;

/**
  Copyright (C) 2011, 2017 Ettore Merlo - All rights reserved
 */

public class globalOptionsMain {

    public static void main(String[] args) throws IOException {

	Integer retVal = null;
	boolean errCode = true;

	globalOptionsCl.read("options.dat");

	globalOptionsCl.srtPrint();

	if (globalOptionsCl.test("printTests", "true")) {
	    System.out.println("printTest OK");
	} else {
	    System.out.println("printTest problem");
	}

	if (globalOptionsCl.test("printTests", "xxxx")) {
	    System.out.println("printTest problem");
	} else {
	    System.out.println("printTest OK");
	}

	if (globalOptionsCl.test("printMetrics", "false")) {
	    System.out.println("printMetrics OK");
	} else {
	    System.out.println("printMetrics problem");
	}

	if (globalOptionsCl.test("printConfig", "false")) {
	    System.out.println("printConfig problem");
	} else {
	    System.out.println("printConfig OK");
	}

	/*
	errCode = globalOptionsCl.intGet("intVal", retVal);
	if (errCode) {
	    System.out.println("intGet problem");
	}
	System.out.println("INT_VAL: " + retVal);


	errCode = globalOptionsCl.intGet("printMetrics", retVal);
	if (errCode) {
	    System.out.println("intGet problem");
	}
	System.out.println("INT_VAL: " + retVal);
	*/



	retVal = globalOptionsCl.intGet("intVal");
	if (retVal == null) {
	    System.out.println("intGet problem");
	} else {
	    System.out.println("INT_VAL: " + retVal.intValue());
	}

	retVal = globalOptionsCl.intGet("printMetrics");
	if (retVal == null) {
	    System.out.println("intGet problem");
	} else {
	    System.out.println("INT_VAL: " + retVal.intValue());
	}






	System.out.println("Normal termination");
    }
}
