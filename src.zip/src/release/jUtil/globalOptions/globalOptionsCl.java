package release.jUtil.globalOptions;

import java.util.*;

import java.io.*;
import java.io.Serializable;

/**
  Copyright (C) 2011, 2017 Ettore Merlo - All rights reserved
 */

public class globalOptionsCl {

    private static HashMap<String, String> optMap = new HashMap<String, String>();

    public static void read(String optFileName)
	throws IOException,FileNotFoundException
    {
	Scanner s = null;

	s = new Scanner(new BufferedReader(new FileReader(optFileName)));
	String optStr = "";
	String valStr = "";

	while (s.hasNext()) {

	    optStr = s.next();
	    //System.out.print("STR: " + optStr);
	    if (!s.hasNext()) {
		System.err.println("ERROR: missing value for option " + optStr);
		System.exit(1);
	    }

	    valStr = s.next();
	    //System.out.println(" VAL: " + valStr);

	    if (optStr.charAt(0) != '#') {

		if (optMap.containsKey(optStr)) {
		    System.err.println("ERROR: duplicate value for option " + optStr);
		    System.exit(1);
		}
		optMap.put(optStr, valStr);
	    }
	}

	s.close();
    }

    /*
    public optionsCl() {
	return;
    }
    */

    public static void print() {
	System.out.println("OPTIONS --->");
	for (String optStr: optMap.keySet()) {
	    System.out.println("\t" + optStr +
			       " " + optMap.get(optStr));
	}
	System.out.println("<--- OPTIONS");
    }

    public static void srtPrint() {
	ArrayList<String> optArr = new ArrayList<String>(optMap.keySet());
	Collections.sort(optArr);

	System.out.println("OPTIONS --->");
	for (String optStr: optArr) {
	    System.out.println("\t" + optStr +
			       " " + optMap.get(optStr));
	}
	System.out.println("<--- OPTIONS");
    }

    public static boolean test(String optStr, String valStr) {

	    if (!optMap.containsKey(optStr)) {
		return(false);
	    } else {
		return(optMap.get(optStr).equals(valStr));
	    }
    }

    public static boolean isDefined(String optStr) {

	    if (optMap.containsKey(optStr)) {
		return(true);
	    } else {
		return(false);
	    }
    }

    public static String get(String optStr) {

	    if (!optMap.containsKey(optStr)) {
		return("");
	    } else {
		return(optMap.get(optStr));
	    }
    }

    public static String stringGet(String optStr) {

	return(optMap.get(optStr));
    }

    public static Integer intGet(String optStr) {

	Integer retVal = null;

	if (!optMap.containsKey(optStr)) {
	    System.err.println("ERROR: invalid option " + optStr);
	    return(retVal);
	}

	try {
	    retVal = new Integer(Integer.valueOf(optMap.get(optStr)));
	}
	catch (NumberFormatException e) {
	    retVal = null;
	    System.err.println("ERROR: invalid integer value: \"" + optMap.get(optStr) + "\"");
	    System.err.println("ERROR: " + e.getMessage());
	    return(retVal);
	}

	return(retVal);
    }

    public static void set(String optStr, String valStr) {

	    optMap.put(optStr, valStr);
    }
}
