package release.jUtil.encodeDecode.src1;//import java.util.Iterator;
//import java.util.Hashtable;
//import java.util.Enumeration;
//import java.util.Set;
//import java.util.HashSet;
//import java.util.ArrayList;

import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
//import java.lang.reflect.*;

/**
  Copyright (C) 2015 Ettore Merlo - All rights reserved
 */

public class stringEncodeDecodeSeparatorSetMain {

    public static void main(String args[]) throws InternalError {

	stringEncodeDecodeSeparatorSetCl coder =
	    new stringEncodeDecodeSeparatorSetCl();

	coder.addSeparator(' ');

	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();

	String str = "a b c d\\ ";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println();

	System.out.println("STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(coder.encode(str)) +
			   ">");
	System.out.println();



	str = "a\nb\nc\nd";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(coder.encode(str)) +
			   ">");
	System.out.println();




	str = "1\\";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(str) +
			   ">");
	System.out.println();



	BufferedWriter tabFile = null;
	String fileName = "encodedFile.dat";

	try {
	    tabFile = new BufferedWriter(new FileWriter(fileName));

	    str = "a b c d\\ ";
	    coder.encode(str, tabFile);

	    tabFile.write('\n');
	    tabFile.close();
	}
	catch (IOException e) {
	    System.out.println(e.getMessage());
	    e.printStackTrace();
	}

	//
	// new separator
	//

	coder.addSeparator('_');

	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();


	str = "a_b_c_d\\_";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println();

	System.out.println("STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(coder.encode(str)) +
			   ">");
	System.out.println();



	coder.addSeparator('\n');

	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();



	str = "a\nb\nc\nd";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   coder.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(coder.encode(str)) +
			   ">");
	System.out.println();



	str = "1\\";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("DEC STR: <" +
			   coder.decode(str) +
			   ">");
	//System.out.println();









	System.exit(0);
    }

}
