package release.jUtil.encodeDecode.src1;//import java.util.Iterator;
//import java.util.Hashtable;
//import java.util.Enumeration;
//import java.util.Set;
//import java.util.HashSet;
//import java.util.ArrayList;

import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
//import java.lang.reflect.*;

/**
  Copyright (C) 2015 Ettore Merlo - All rights reserved
 */

public class stringEncodeDecodeTabularSeparatorsMain {

    public static void main(String args[]) throws InternalError {

	/*
	stringEncodeDecodeTabularSeparatorsCl coder =
	    new stringEncodeDecodeTabularSeparatorsCl();
	*/

	/*
	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();
	*/

	String str = "a b c d\\ ";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println();

	System.out.println("STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(stringEncodeDecodeTabularSeparatorsCl.encode(str)) +
			   ">");
	System.out.println();



	str = "a\nb\nc\nd";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(stringEncodeDecodeTabularSeparatorsCl.encode(str)) +
			   ">");
	System.out.println();




	str = "1\\";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(str) +
			   ">");
	System.out.println();



	BufferedWriter tabFile = null;
	String fileName = "encodedFile.dat";

	try {
	    tabFile = new BufferedWriter(new FileWriter(fileName));

	    str = "a b c d\\ ";
	    stringEncodeDecodeTabularSeparatorsCl.encode(str, tabFile);

	    tabFile.write('\n');
	    tabFile.close();
	}
	catch (IOException e) {
	    System.out.println(e.getMessage());
	    e.printStackTrace();
	}

	/*
	//
	// new separator
	//

	coder.addSeparator('_');

	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();
	*/

	str = "a_b_c_d\\_";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println();

	System.out.println("STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(stringEncodeDecodeTabularSeparatorsCl.encode(str)) +
			   ">");
	System.out.println();


	/*
	coder.addSeparator('\n');

	System.out.println("SEPARATOR SET:");
	coder.printSeparators();
	System.out.println();
	*/


	str = "a\nb\nc\nd";

	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("ENC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.encode(str) +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(stringEncodeDecodeTabularSeparatorsCl.encode(str)) +
			   ">");
	System.out.println();



	str = "1\\";
	System.out.println("STR: <" +
			   str +
			   ">");
	System.out.println("DEC STR: <" +
			   stringEncodeDecodeTabularSeparatorsCl.decode(str) +
			   ">");
	//System.out.println();



	System.exit(0);
    }

}
