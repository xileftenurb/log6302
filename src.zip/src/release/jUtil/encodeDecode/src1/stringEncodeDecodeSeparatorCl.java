package release.jUtil.encodeDecode.src1;//import java.util.HashMap;
//import java.util.Enumeration;
//import java.util.Set;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.concurrent.ConcurrentHashMap;

import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;

/**
  Copyright (C) 2015 - 2016 Ettore Merlo - All rights reserved
*/

//public class stringEncodeDecodeCl implements defsInt {
public class stringEncodeDecodeSeparatorCl {

    private char sep = '\0';

    public stringEncodeDecodeSeparatorCl() {
	return;
    }

    public stringEncodeDecodeSeparatorCl(char parSep) {
	sep = parSep;
	return;
    }

    public void setSeparator(char parSep) {
	sep = parSep;
	return;
    }

    public String encode(String str) {

	char[] cBuf = new char[1];
	cBuf[0] = '\0';

	char[] slashBuf = new char[1];
	slashBuf[0] = '\\';
	
	String localStr = "";

	for (int i=0; i < str.length();++i) {

	    cBuf[0] = str.charAt(i);

	    if ((cBuf[0] == sep) || (cBuf[0] == '\\')) {

		localStr = localStr.concat(new String(slashBuf));
		localStr = localStr.concat(new String(cBuf));

	    } else {
		localStr = localStr.concat(new String(cBuf));
	    }
	}

	return(localStr);
    }

    public void encode(String str, BufferedWriter osr)
	throws IOException {

	char cBuf =  '\0';
	char slashBuf =  '\\';

	for (int i=0; i < str.length();++i) {

	    cBuf = str.charAt(i);

	    if ((cBuf == sep) || (cBuf == '\\')) {
		osr.write(slashBuf);
		osr.write(cBuf);
	    } else {
		osr.write(cBuf);
	    }
	}

	return;
    }

    public String decode(String str) {

	char[] cBuf = new char[1];
	cBuf[0] = '\0';

	String localStr = "";

	int i = 0;
	while (i < str.length()) {

	    cBuf[0] = str.charAt(i);

	    //System.out.println("CH: <" + cBuf[0] + ">");

	    if (cBuf[0] == '\\') {

		if ((i+1) >= str.length()) {
		    return(null);
		}

		++i;

		cBuf[0] = str.charAt(i);
		localStr = localStr.concat(new String(cBuf));

	    } else {
		localStr = localStr.concat(new String(cBuf));
	    }

	    ++i;
	}

	return(localStr);
    }
}
