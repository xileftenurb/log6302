package release.table_manip.java_rel_table.entryTables.src1; /**
  Copyright (C) Nov 2017 Ettore Merlo - All rights reserved
 */

import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Collection;

import java.io.File;
import java.io.IOException;

import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

import release.jUtil.tkLines.src2.*;

public class tableReaderCl implements defsInt {

    private escTkLinesCl tkLines = new escTkLinesCl();

    private tableReadVisCl tableReadVis = new tableReadVisCl();

    public void initParams(Object parObj) {

	tableReadVis.initParams(parObj);
	return;
    }

    public void read(String fileName) {

	ArrayList<String> lineStr = null;
	boolean errCode = true;
	int lineNo = 0;


	errCode = tkLines.open(fileName);
	if (errCode) {
	    System.err.println("ERROR: cannot open " + fileName);
	    System.exit(1);
	}

	errCode = tkLines.readNext();
	if (errCode) {
		System.err.println("ERROR: cannot read first line");
		System.exit(1);
	}

	while (tkLines.currentIsValid()) {

	    lineNo++;

	    lineStr = tkLines.getCurrent();
	    if (lineStr == null) {
		System.err.println("ERROR: cannot get line " +
				   lineNo);
		System.exit(1);
	    }

	    /*
	    System.out.println("DEBUG LINE: " +
			       " " +
			       lineNo +
			       ": " +
			       lineStr);
	    */
	    tableReadVis.read(lineStr, lineNo);

	    errCode = tkLines.readNext();

	    if (errCode) {
		System.err.println("ERROR: cannot read next line at line " +
				   lineNo);
		System.exit(1);
	    }
	}

	tkLines.close();

	if (globalOptionsCl.test("printTableReaderWarnings", "true")) {
	    tableReadVis.printUndefTables();
	}

	return;
    }

    //
    // func
    //

    static public void readLine_func_Integer_Integer(ArrayList<String> lineArr,
						     int lineNo,
						     Map<Integer, Integer> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (3 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	Integer domVal = null;
	try {
	    domVal = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid integer dom val " +
			       lineArr.get(1));
            System.exit(1);
        }

	Integer ranVal = null;
	try {
	    ranVal = Integer.valueOf(lineArr.get(2));
	} catch (NumberFormatException e) {
	    System.err.println(e.getMessage());
	    e.printStackTrace();
	    System.err.println("ERROR: invalid integer ran val " +
			       lineArr.get(2));
	    System.exit(1);
	}

	parTable.put(domVal, ranVal);

	return;
    }

    static public void readLine_func_Integer_String(ArrayList<String> lineArr,
						    int lineNo,
						    Map<Integer, String> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (3 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	Integer domVal = null;
	try {
	    domVal = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid integer dom val " +
			       lineArr.get(1));
            System.exit(1);
        }

	parTable.put(domVal, lineArr.get(2));

	return;
    }

    static public void readLine_func_String_Integer(ArrayList<String> lineArr,
						    int lineNo,
						    Map<String, Integer> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (3 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	/*
	Integer domVal = null;
	try {
	    domVal = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid integer dom val " +
			       lineArr.get(1));
            System.exit(1);
        }
	*/

	Integer ranVal = null;
	try {
	    ranVal = Integer.valueOf(lineArr.get(2));
	} catch (NumberFormatException e) {
	    System.err.println(e.getMessage());
	    e.printStackTrace();
	    System.err.println("ERROR: invalid integer ran val " +
			       lineArr.get(2));
	    System.exit(1);
	}

	parTable.put(lineArr.get(1), ranVal);

	return;
    }

    static public void readLine_func_String_String(ArrayList<String> lineArr,
						   int lineNo,
						   Map<String, String> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (3 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	parTable.put(lineArr.get(1), lineArr.get(2));

	return;
    }

    //
    // funcTupleRan
    //

    static public void readLine_funcTupleRan_Integer_String(ArrayList<String> lineArr,
							    int lineNo,
							    Map<Integer, ArrayList<String>> parTable,
							    int ranSize) {

	if ((ranSize != UNDEF_VAL) && (lineArr.size() != ranSize)) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (" +
			       ranSize +
			       " expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.subList(2, lineArr.size()));
	}

	Integer domVal = null;
	try {
	    domVal = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid integer dom val " +
			       lineArr.get(1));
            System.exit(1);
        }

	parTable.put(domVal,
		    new ArrayList<String>(lineArr.subList(2, lineArr.size())));

	return;
    }

    static public void readLine_funcTupleRan_String_Integer(ArrayList<String> lineArr,
							    int lineNo,
							    Map<String, ArrayList<Integer>> parTable,
							    int ranSize) {

	if ((ranSize != UNDEF_VAL) && (lineArr.size() != ranSize)) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (" +
			       ranSize +
			       " expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.subList(2, lineArr.size()));
	}

	Integer ranVal = null;
	ArrayList<Integer> ranArr = new ArrayList<Integer>();
	for (String ranStr:
		 globalOptionsCl.test("printTests", "true") ?
		 sortUtilsCl.
		 getIntSortedIterable_String(lineArr.subList(2, lineArr.size())) :
		 lineArr.subList(2, lineArr.size())) {

	    try {
		ranVal = Integer.valueOf(ranStr);
	    } catch (NumberFormatException e) {
		System.err.println(e.getMessage());
		e.printStackTrace();
		System.err.println("ERROR: invalid integer ran val " +
				   ranStr);
		System.exit(1);
	    }

	    ranArr.add(ranVal);
	}

	parTable.put(lineArr.get(1), ranArr);

	return;
    }

    static public void readLine_funcTupleRan_String_String(ArrayList<String> lineArr,
							    int lineNo,
							    Map<String, ArrayList<String>> parTable,
							    int ranSize) {

	if ((ranSize != UNDEF_VAL) && (lineArr.size() != ranSize)) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (" +
			       ranSize +
			       " expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.subList(2, lineArr.size()));
	}

	ArrayList<String> ranArr = new ArrayList<String>();
	for (String ranStr:
		 globalOptionsCl.test("printTests", "true") ?
		 sortUtilsCl.
		 getIntSortedIterable_String(lineArr.subList(2, lineArr.size())) :
		 lineArr.subList(2, lineArr.size())) {

	    ranArr.add(ranStr);
	}

	parTable.put(lineArr.get(1), ranArr);

	return;
    }

    //
    // vectRel
    //

    static public void readLine_vectRel_Integer_Integer(ArrayList<String> lineArr,
							int lineNo,
							Map<Integer, ArrayList<Integer>> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       "3  expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key " +
			       lineArr.get(1) +
			       " for succ table at line " +
			       lineNo);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	Integer domId = null;
	try {
	    domId = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid dom id " +
			       lineArr.get(1));
            System.exit(1);
        }

	Integer ranId = null;

	try {
	    ranId = Integer.valueOf(lineArr.get(2));
	} catch (NumberFormatException e) {
	    System.err.println(e.getMessage());
	    e.printStackTrace();
	    System.err.println("ERROR: invalid ran id " +
			       lineArr.get(2));
	    System.exit(1);
	}

	if (!parTable.containsKey(domId)) {
	    parTable.put(domId,
			 new ArrayList<Integer>());
	}

	parTable.get(domId).add(ranId);

	return;
    }

    //
    // set
    //

    static public void readLine_set_Integer(ArrayList<String> lineArr,
					    int lineNo,
					    Set<Integer> parTable) {

	if (lineArr.size() != 2) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (2 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.contains(lineArr.get(1))) {
	    System.out.println("WARNING: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	} else {

	    if (globalOptionsCl.test("printTableReaderTests", "true")) {
		System.out.println("READ: " +
				   lineArr.get(1));
	    }

	    Integer domVal = null;
	    try {
		domVal = Integer.valueOf(lineArr.get(1));
	    } catch (NumberFormatException e) {
		System.err.println(e.getMessage());
		e.printStackTrace();
		System.err.println("ERROR: invalid integer dom val " +
				   lineArr.get(1));
		System.exit(1);
	    }

	    parTable.add(domVal);

	}

	return;
    }

    static public void readLine_set_String(ArrayList<String> lineArr,
					   int lineNo,
					   Set<String> parTable) {

	if (lineArr.size() != 2) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (2 expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.contains(lineArr.get(1))) {
	    System.out.println("WARNING: duplicate key at line " +
			       lineNo +
			       ": " +
			       lineArr);
	} else {

	    if (globalOptionsCl.test("printTableReaderTests", "true")) {
		System.out.println("READ: " +
				   lineArr.get(1));
	    }

	    parTable.add(lineArr.get(1));
	}

	return;
    }

    //
    // iterable
    //

    static public void readLine_vectRel_Integer_Iterable_Integer(ArrayList<String> lineArr,
								 int lineNo,
								 Map<Integer, Iterable<Integer>> parTable) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       "3  expected) for line: " +
			       lineArr);
	    System.exit(1);
	}

	if (parTable.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key " +
			       lineArr.get(1) +
			       " for succ table at line " +
			       lineNo);
	    System.exit(1);
	}

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("READ: " +
			       lineArr.get(1) +
			       " " +
			       lineArr.get(2));
	}

	Integer domId = null;
	try {
	    domId = Integer.valueOf(lineArr.get(1));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid dom id " +
			       lineArr.get(1));
            System.exit(1);
        }

	Integer ranId = null;

	try {
	    ranId = Integer.valueOf(lineArr.get(2));
	} catch (NumberFormatException e) {
	    System.err.println(e.getMessage());
	    e.printStackTrace();
	    System.err.println("ERROR: invalid ran id " +
			       lineArr.get(2));
	    System.exit(1);
	}

	if (!parTable.containsKey(domId)) {
	    parTable.put(domId,
			 new ArrayList<Integer>());
	}

	((ArrayList<Integer>) parTable.get(domId)).add(ranId);

	return;
    }



}
