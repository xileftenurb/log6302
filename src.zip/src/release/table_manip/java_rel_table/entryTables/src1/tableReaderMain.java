package release.table_manip.java_rel_table.entryTables.src1;

import java.util.Iterator;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;

import java.io.File;
import java.io.IOException;

import java.lang.reflect.*;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

/**
  Copyright (C) 2017 Ettore Merlo - All rights reserved
*/

public class tableReaderMain {

    public static void main(String args[]) {

	tableReaderCl tableReader = new tableReaderCl();
	//tableReadVisCl tableReadVis = new tableReadVisCl();
	tableCl table = new tableCl();

	try {
	    globalOptionsCl.read("options.dat");
        } catch (IOException e) {
	    System.out.println("ERROR: cannot open options.dat");
	    System.exit(1);
        }
	if (globalOptionsCl.test("printOptions", "true")) {
	    globalOptionsCl.print();
	}

	//tableReadVis.initParams(table);
	tableReader.initParams(table);

	//
	// read table
	//

	String tableStr = "table.tab";

	//tableReader.read(tableStr, tableReadVis);
	tableReader.read(tableStr);

	if (globalOptionsCl.test("printTable", "true")) {
	    System.out.println("PRINT --->");

	    //System.out.println(table.table_1);
	    for (Integer k: sortUtilsCl.getSortedIterable_Integer(table.table_1.keySet())) {
		System.out.println(k + " " + table.table_1.get(k));
	    }
	    System.out.println();

	    //System.out.println(table.table_2);
	    for (Integer k: sortUtilsCl.getSortedIterable_Integer(table.table_2.keySet())) {
		System.out.println(k + " " + table.table_2.get(k));
	    }
	    System.out.println();

	    //System.out.println(table.table_3);
	    for (String k: sortUtilsCl.getSortedIterable_String(table.table_3.keySet())) {
		System.out.println(k + " " + table.table_3.get(k));
	    }

	    System.out.println("<--- PRINT");
	    System.out.println();
	}

	System.out.println("Successful termination");

	System.exit(0); 
    }

}
