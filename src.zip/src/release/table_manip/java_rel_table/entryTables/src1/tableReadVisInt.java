package release.table_manip.java_rel_table.entryTables.src1; /**
  Copyright (C) Nov 2017 Ettore Merlo - All rights reserved
 */

import java.util.ArrayList;

public interface tableReadVisInt {

    public void read(ArrayList<String> line,
		     int lineNo);

}
