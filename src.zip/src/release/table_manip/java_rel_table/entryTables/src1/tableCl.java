package release.table_manip.java_rel_table.entryTables.src1; /**
  Copyright (C) Nov 2017 Ettore Merlo - All rights reserved
 */

import java.util.ArrayList;
import java.util.HashMap;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

class tableCl implements defsInt {

    public HashMap<Integer, ArrayList<String>> table_1 =
	new HashMap<Integer, ArrayList<String>>();
    public HashMap<Integer, Integer> table_2 =
	new HashMap<Integer, Integer>();
    public HashMap<String, ArrayList<Integer>> table_3 =
	new HashMap<String, ArrayList<Integer>>();

    /*
    public HashMap<String, String> readMap = new HashMap<String, String>();

    tableCl() {
	readMap.add("table_4","read_4");
	readMap.add("table_5","read_5");
    }
    */

    /*
    public void readLine_table_1(ArrayList<String> lineArr,
				 Integer lineNo) {

	if (lineArr.size() != 5) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (5 expected) for table_1 at line " +
			       lineArr);
	    System.exit(1);
	}

	if (table_1.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key " +
			       lineArr.get(0) +
			       " for table_1 at line " +
			       lineNo);
	    System.exit(1);
	}

	System.out.println("READ TABLE_1: " +
			   lineArr.get(1) +
			   " " +
			   lineArr.subList(2, lineArr.size()));

	table_1.put(lineArr.get(1),
		    new ArrayList<String>(lineArr.subList(2, lineArr.size())));

	System.out.println("TABLE_1: " + table_1);

	return;
    }

    public void readLine_table_2(ArrayList<String> lineArr,
				 Integer lineNo) {

	if (lineArr.size() != 3) {
	    System.err.println("ERROR: invalid line length " +
			       lineArr.size() +
			       " at line " +
			       lineNo +
			       " (3 expected) for table_2 at line " +
			       lineArr);
	    System.exit(1);
	}

	if (table_2.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key " +
			       lineArr.get(0) +
			       " for table_2 at line " +
			       lineNo);
	    System.exit(1);
	}

	System.out.println("READ TABLE_2: " +
			   lineArr.get(1) +
			   " " +
			   lineArr.subList(2, lineArr.size()));

	table_2.put(lineArr.get(1),
		    new ArrayList<String>(lineArr.subList(2, lineArr.size())));

	System.out.println("TABLE_2: " + table_2);

	return;
    }

    public void readLine_table_3(ArrayList<String> lineArr,
				 Integer lineNo) {

	if (table_3.containsKey(lineArr.get(1))) {
	    System.out.println("ERROR: duplicate key " +
			       lineArr.get(0) +
			       " for table_3 at line " +
			       lineNo);
	    System.exit(1);
	}

	System.out.println("READ TABLE_3: " +
			   lineArr.get(1) +
			   " " +
			   lineArr.subList(2, lineArr.size()));

	table_3.put(lineArr.get(1),
		    new ArrayList<String>(lineArr.subList(2, lineArr.size())));

	System.out.println("TABLE_3: " + table_3);

	return;
    }
    */

    public void readLine_table_1(ArrayList<String> lineArr,
				 Integer lineNo) {

	tableReaderCl.readLine_funcTupleRan_Integer_String(lineArr,
							   lineNo,
							   table_1,
							   5);
	return;
    }


    public void readLine_table_2(ArrayList<String> lineArr,
				 Integer lineNo) {

	tableReaderCl.readLine_func_Integer_Integer(lineArr,
						    lineNo,
						    table_2);
	return;
    }

    public void readLine_table_3(ArrayList<String> lineArr,
				 Integer lineNo) {

	tableReaderCl.readLine_funcTupleRan_String_Integer(lineArr,
							   lineNo,
							   table_3,
							   UNDEF_VAL);
	return;
    }

}
