package release.table_manip.java_rel_table.entryTables.src1; /**
  Copyright (C) Nov 2017 Ettore Merlo - All rights reserved
 */

import java.util.ArrayList;
import java.util.HashSet;
import java.lang.reflect.*;
import release.jUtil.globalOptions.globalOptionsCl;
import release.jUtil.defs.defsInt;
import release.jUtil.sorted.src1.sortUtilsCl;
import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;

class tableReadVisCl
    implements tableReadVisInt {

    private static final Class<?>[] params_ArrayList_Integer = {ArrayList.class,
								Integer.class};

    private HashSet<String> undefTableSet = new HashSet<String>();

    private Object tableObj = null;

    public void initParams(Object parObj) {

	tableObj = parObj;

	return;
    }

    public void read(ArrayList<String> line,
		     int lineNo) {

	//
	// define reading func
	//

	Method readingFunc = null;
	String methodName = "readLine_" + line.get(0);

	if (globalOptionsCl.test("printTableReaderTests", "true")) {
	    System.out.println("METHOD NAME: " + methodName);
	}

	try {
	    readingFunc = tableObj.getClass().getMethod(methodName,
							params_ArrayList_Integer);
	} catch (NoSuchMethodException e) {
	    //System.out.println(e.getMessage());
	    //e.printStackTrace();
	    //System.exit(1);

	    /*
	    System.out.println("WARNING: undefined table " +
			       line.get(0));
	    */

	    undefTableSet.add(line.get(0));
	    readingFunc = null;
	}

	if (readingFunc != null) {
	    try {
		readingFunc.invoke(tableObj, line, lineNo);
	    } catch (IllegalArgumentException |
		     IllegalAccessException |
		     InvocationTargetException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
		System.exit(1);
	    }
	}

	return;
    }

    public void printUndefTables() {

	for (String item: undefTableSet) {
	    System.out.println("WARNING: undefined table " +
			       item);
	}
	System.out.println();

	return;
    }

}
