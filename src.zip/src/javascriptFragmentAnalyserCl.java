import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class javascriptFragmentAnalyserCl {

    javascriptParseTableCl astTable = null;

    public void initParams(javascriptParseTableCl parAstTable) {
        astTable = parAstTable;
        return;
    }

    /**
     * @param fragment
     * @return vector
     */
    public List<Integer> parseFragment(List<Integer> fragment) {

        List<Integer> dataVector = new ArrayList<Integer>();
        return dataVector;
    }

    public Map<String, Integer> getTypeNoeud(List<Integer> fragment) {
        Map<String, Integer> mapNoeud = new HashMap<>();
        for(Integer noNoeud : fragment) {
            String currentType = astTable.getType(noNoeud);
            Integer currentNbr = mapNoeud.get(currentType);
            if(currentNbr == null) {
                currentNbr = 0;
            }
            mapNoeud.put(currentType, currentNbr+1);
        }
        return mapNoeud;
    }

    //je fais l'hypothèse que toute fonction inline est appeller dans le même fragment qu'il est défini en moyenne, de sorte
    //que la complexité du fragment entier est lier à la complexité de ses fonctions inline.
    private Integer getComplexiterCyclomatique(List<Integer> fragment) {
        //le nombre de point de décision - le nombre de sortie + 2
        //point de décision : if, switch, AND, OR, if ternaire, while, for, for of, for in,

        //on peut ignorer les exceptions comme ne faisant pas partie du cours normal.
        //cependant, je n'ignorerais pas le contenus des block "catchs" je concidèrerais que les catch ont un point entrant et un point sortant.
        //le départ de ce point entrant est inconnu (puisqu'il s'agit de "quand il y aura une exception") et n'augmente donc pas la complexité en soit d'ajouter
        //un catch. mais le contenus du catch peut avoir des noeuds augmentant la complexité.
        return 0;
    }

    private Integer getNombreBranchement(List<Integer> fragment) {
        //le nombre de noeud if ou de else if.
        //le nombre de else n'a pas d'impact.

        //le nombre de case dans le switch (default exclus)

        //le nombre de "?:", de "OR" et de "AND"
        return 0;
    }

    private Integer getNombreWhile(List<Integer> fragment) {
        //while, for, for in, for of.
        //en théorie, forEach, map, reduce, filter, some, every, etc. sont des fonctions qui ont une boucle (au minimum)
        //mais on ne les conteras pas.
        //Il est possible de transformé une boucle en fonction recursif, mais celui-ci aura alors un if de terminaison
        // (ou alors il s'agit d'une boucle infini), et aura donc la même complexit que la boucle direct.

        return 0;
    }

    private Integer getNombreVar(List<Integer> fragment) {
        return 0;
    }

    private Integer getNombreFctCall(List<Integer> fragment) {
        return 0;
    }

    private Integer getNombreLiteral(List<Integer> fragment) {
        return 0;
    }
}
