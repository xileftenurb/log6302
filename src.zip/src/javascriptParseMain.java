    import java.util.*;

    import java.io.IOException;
    import release.jUtil.globalOptions.globalOptionsCl;
    import release.jUtil.sorted.src1.sortUtilsCl;
    import release.table_manip.java_rel_table.entryTables.src1.tableReaderCl;



    /**
    Copyright (C) 2017, 2018, 2019 Ettore Merlo - All rights reserved
    */

    public class javascriptParseMain {

    public static void dfsTraverse(Integer nodeId,
                   Set<Integer> visited,
                   Map<Integer, ArrayList<Integer>> adjTable) {


    // set discovered
    visited.add(nodeId);

    // visit current node


    if (adjTable.containsKey(nodeId)) {
        for (Integer childId:
             globalOptionsCl.test("srtTraversal", "true") ?
                sortUtilsCl
                    .getSortedIterable_Integer(adjTable.get(nodeId)) :
                adjTable.get(nodeId)) {


            if (!visited.contains(childId)) {

                System.out.println("NEXT TRANS: " + nodeId + " " + childId);

                //data.parent = id;
                dfsTraverse(childId, visited, adjTable);
            } else {

            }
        }
    }

    return;
    }

    public static void main(String args[]) {

        javascriptParseTableCl astTable = new javascriptParseTableCl();
        tableReaderCl tableReader = new tableReaderCl();

        try {
            globalOptionsCl.read("options.dat");
        } catch (IOException e) {
            System.out.println("ERROR: cannot open options.dat");
            System.exit(1);
        }

        if (globalOptionsCl.test("printOptions", "true")) {
            globalOptionsCl.print();
        }

        tableReader.initParams(astTable);

        if (args.length != 1) {
            System.err.println("ERROR: missing filename");
            System.exit(1);
        }

        //String tableStr = "tripleTable.tab";
        String tableStr = args[0];

        //
        // read table
        //

        tableReader.read(tableStr);
        astTable.print();

        //
        // get AST root
        //

        Integer rootNodeId = null;

        if (!astTable.attrTable.containsKey("ast_root")) {
            System.out.println("ERROR: undefined attribute \"ast_root\"");
            System.exit(1);
        }
        try {
            rootNodeId = Integer.valueOf(astTable.attrTable.get("ast_root"));
        } catch (NumberFormatException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.err.println("ERROR: invalid parent integer " +
                               astTable.attrTable.get("ast_root"));
            System.exit(1);
        }


        javascriptAstPrettyPrintVisCl javascriptPrintVis =
            new javascriptAstPrettyPrintVisCl();
        javascriptPrintVis.initParams(astTable);
        javascriptPrintVis.visit(rootNodeId, 0);


        javascriptAstFragmentVisCl javascriptFragVis =
                new javascriptAstFragmentVisCl ();
        javascriptFragVis.initParams(astTable, 10);
        List<List<Integer>> listFrag = javascriptFragVis.visit(rootNodeId, 0);


        System.out.println("Successful termination");
        System.exit(0);
    }

}
