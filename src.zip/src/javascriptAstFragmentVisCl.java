import release.jUtil.defs.defsInt;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

/**
  Copyright (C) Jan 2019 Félix Brunet - All rights reserved
*/

public class javascriptAstFragmentVisCl implements defsInt {


    javascriptParseTableCl astTable = null;

    private int threshold;

    public void initParams(javascriptParseTableCl parAstTable, int pthreshold) {
        threshold = pthreshold;
        astTable = parAstTable;
        return;
    }

    private List<List<Integer>> mergeFrag(List<List<List<Integer>>> listOfSubFrag) {
        List<List<Integer>> listFrag = new ArrayList<>();
        List<Integer> incompleteFrag = new ArrayList<>();
        for(List<List<Integer>> subFrag : listOfSubFrag) {
            listFrag.addAll(subFrag.subList(0, subFrag.size() -1));
            incompleteFrag.addAll(subFrag.get(subFrag.size() -1));
        };
        listFrag.add(incompleteFrag);
        return listFrag;
    }

    private List<List<Integer>> visitChildren(Integer astNodeId, int depth) {
        List<List<List<Integer>>> listOfSubFrag = new ArrayList<>();
        List<Entry<Integer, String>> children = astTable.succTable.get(astNodeId);
        if (children != null) {
            for (Entry<Integer, String> childEntry: children) {
                listOfSubFrag.add(visit(childEntry.getKey(), depth));
            }
        }
        return mergeFrag(listOfSubFrag);
    }

    /////////////////////////////////////////////////////

    private List<List<Integer>> visit_default(Integer astNodeId, int depth, String nodeType) {
        List<List<Integer>> listFrag = visitChildren(astNodeId, (depth + 1));
        listFrag.get(listFrag.size()-1).add(astNodeId);
        return listFrag;
    }

    private List<List<Integer>> visit_fragment(Integer astNodeId, int depth, String nodeType) {
        List<List<Integer>> listFrag = visitChildren(astNodeId, (depth + 1));
        List<Integer> incompleteFrag = listFrag.get(listFrag.size()-1);
        incompleteFrag.add(astNodeId);
        if(incompleteFrag.size() >= threshold) {
            //new fragment
            listFrag.add(new ArrayList<>());
        }
        return listFrag;
    }

    /////////////////////////////////////////////////////

    public List<List<Integer>> visit(Integer astNodeId, int depth) {
        List<List<Integer>> retVal;
        String curType = astTable.getType(astNodeId);
        if (curType == null) {
            System.err.println("ERROR: missing node " +
                       astNodeId);
            System.exit(1);
        }

        switch (curType) {
            case "FunctionDeclaration":
            case "FunctionExpression":
            case "ArrowFunctionExpression":
                retVal = visit_fragment(astNodeId, depth, curType);
                break;
            default:
                retVal = visit_default(astNodeId, depth, curType);
                break;
        }
        return retVal;
    }
}
